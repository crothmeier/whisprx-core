# Whisprx Core bundle
