class RateMonitor: pass
