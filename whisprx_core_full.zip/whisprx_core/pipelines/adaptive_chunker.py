class FlowControlledBuffer: pass
