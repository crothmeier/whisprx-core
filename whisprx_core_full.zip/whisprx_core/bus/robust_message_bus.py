class RobustMessageBus: pass
